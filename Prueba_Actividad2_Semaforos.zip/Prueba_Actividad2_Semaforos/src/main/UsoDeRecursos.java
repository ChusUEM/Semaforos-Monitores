package main;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class UsoDeRecursos {

    private Semaphore productosDisponibles; // productos iniciales = 0
    private Semaphore productosEnCola; // para controlar la cantidad máxima de productos que se pueden almacenar en la cola.
    private Semaphore semaforoMutex; // para controlar el acceso a la cola
    private Queue<Integer> cola;

    public UsoDeRecursos(int k) {
        productosDisponibles = new Semaphore(0, true); 
        productosEnCola = new Semaphore(k, true);
        semaforoMutex = new Semaphore(1, true); 
        cola = new LinkedList<>();
    }

    public void producir(int id) throws InterruptedException {
        productosEnCola.acquire();
        semaforoMutex.acquire();
        cola.add(id);
        System.out.println("Se ha creado el producto " + id);
        semaforoMutex.release();
        productosDisponibles.release();
    }

    public void consumir(int cantidad) throws InterruptedException {
        productosDisponibles.acquire(cantidad);
        semaforoMutex.acquire();
        System.out.print("El consumidor ha recibido los siguientes productos: ");
        for (int i = 0; i < cantidad; i++) {
            int idProducto = cola.poll();
            System.out.print(idProducto + " ");
        }
        System.out.println();
        semaforoMutex.release();
        productosEnCola.release(cantidad);
    }

    public static void main(String[] args) {
        int k = 10; // número máximo de productos en la cola
        UsoDeRecursos usoDeRecursos = new UsoDeRecursos(k);

        new Thread(() -> { // creamos nuevo hilo para producir
        	int maxProductos = 50; // fijamos el tamaño máximo de productos creados  	
            for (int i = 1; i <= maxProductos; i++) { 
            	try {
                    usoDeRecursos.producir(i);
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } 
        }).start();

        new Thread(() -> { // creamos nuevo hilo para consumir
        	int reserva = 5; // reserva del consumidor de productos
            for (int i = 1; i <= k; i++) {
                try {
                    usoDeRecursos.consumir(reserva);
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
