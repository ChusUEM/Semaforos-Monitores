package main;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Puente {
	
    private Lock bloquear = new ReentrantLock();
    private Condition surPuedeCruzar = bloquear.newCondition();
    private Condition nortePuedeCruzar = bloquear.newCondition();
    public boolean surCruzando = false;
    public boolean norteCruzando = false;

    public void surQuiereCruzar() throws InterruptedException { // 
        bloquear.lock();
        try {
            while (norteCruzando) {
                surPuedeCruzar.await();
            }
            surCruzando = true;
        } finally {
            bloquear.unlock();
        }
    }

    public void surTerminaDeCruzar() {
        bloquear.lock();
        try {
            surCruzando = false;
            nortePuedeCruzar.signalAll();
        } finally {
            bloquear.unlock();
        }
    }

    public void norteQuiereCruzar() throws InterruptedException {
        bloquear.lock();
        try {
            while (surCruzando) {
                nortePuedeCruzar.await();
            }
            norteCruzando = true;
        } finally {
            bloquear.unlock();
        }
    }

    public void norteTerminaDeCruzar() {
        bloquear.lock();
        try {
            norteCruzando = false;
            surPuedeCruzar.signalAll();
        } finally {
            bloquear.unlock();
        }
    }

    public static void main(String[] args) { 
    	// El método main() crea dos hilos (Thread) que representan un coche que viene del sur y otro que viene 
    	// del norte. Cada hilo llama a los métodos surQuiereCruzar() y norteQuiereCruzar() para indicar que quieren
    	// cruzar el puente, espera unos segundos simulando el tiempo que toma cruzar el puente (Thread.sleep(3000)), 
    	// y luego llama a los métodos surTerminaDeCruzar() y norteTerminaDeCruzar() para indicar que han terminado 
    	// de cruzar el puente. Con los condicionales while() controlamos que puedan alternarse al cruzar el puente
    	// del uno al otro y viceversa.
    	
        Puente puente = new Puente();
        boolean surCruzando = false; 
        boolean norteCruzando = false; //variables booleanas para condicionar la entrada al proceso del coche norte o sur 

        Thread surThread = new Thread(() -> { // nuevo hilo para el coche del sur
            while (!norteCruzando) {
	        	try {
	                puente.surQuiereCruzar();
	                System.out.println("Coche del sur está cruzando el puente");
	                Thread.sleep(3000);
	                puente.surTerminaDeCruzar();
	                System.out.println("Coche del sur ha terminado de cruzar el puente");
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
            }
        });

        Thread norteThread = new Thread(() -> { // nuevo hilo para el coche del norte
        	while (!surCruzando) {
	            try {
	                puente.norteQuiereCruzar();
	                System.out.println("Coche del norte está cruzando el puente");
	                Thread.sleep(3000);
	                puente.norteTerminaDeCruzar();
	                System.out.println("Coche del norte ha terminado de cruzar el puente");
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
        	}
        });

        surThread.start(); // iniciamos los hilos tanto del sur como del norte
        norteThread.start();
    }
}
